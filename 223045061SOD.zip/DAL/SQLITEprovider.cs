﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FR1.DBL.DAL
{
    public  class SQLITEprovider:ProviderBase
    {
        private static List<SmartDevice> devices = new List<SmartDevice>();
        public override List<SmartDevice> selectAll()
        {
            return devices;
        }
        public override int insert(SmartDevice device)
        {
            devices.Add(device);
            return 1;
        }
        public override int delete(SmartDevice device)
        {
            devices.Remove(device);
            return 1;
        }
        public override int update(SmartDevice device)
        {
            var existingDevice = devices.Find(d => d.ID == device.ID);
            if (existingDevice != null)
            {
                existingDevice.FirstName = device.FirstName;
                existingDevice.LastName = device.LastName;
                existingDevice.Age = device.Age;
                return 1;
            }
            return 0;
        }
        public override SmartDevice SelectSmartdevice(string deviceID)
        {
            return devices.Find(d => d.ID == deviceID);
        }
    }
}

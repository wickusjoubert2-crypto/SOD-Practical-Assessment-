﻿using FR1.BL.Class;
using System;
using System.Collections.Generic;
using System.Text;

namespace FR1.DBL.DAL
{
    public abstract class ProviderBase
    {
        public abstract list<SmartDevice> selectAll();
        public abstract int insert(SmartDevice device);
        public abstract int delete(SmartDevice device);
        public abstract int update(SmartDevice device);
        public abstract SelectSmartdevice(string deviceID);

    }
}

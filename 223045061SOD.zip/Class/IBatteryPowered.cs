﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FR1.BL.Class
{
   public interface IBatteryPowered
    {
        int BatteryLevel { get; set; } // end property
    }
}

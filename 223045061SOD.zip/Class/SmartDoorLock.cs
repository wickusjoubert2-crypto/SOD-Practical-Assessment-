﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FR1.BL.Class
{
    public class SmartDoorLock : SmartDevice
    {
        public bool IsLocked { get; set; } // end property
        public override string Display()
        {
            return base.ToString() + $" IsLocked: {IsLocked}";
        }
    }
}

﻿using FR1.DBL.DAL;
using System;
using System.Collections.Generic;
using System.Text;

namespace FR1.BL.Class
{
   public class SmartDeviceBL
    {
        private ProviderBase provider;
        public SmartDeviceBL(string providerType)
        { 
            SetupProviderBase(providerType);

        }
        private void SetupProviderBase(string providerType)
        {
            if (providerType == "SQLITE")
            {
                provider = new SQLITEprovider();
            }
            else
            {
                throw new ArgumentException("Invalid provider type");
            }
        }
        public List<SmartDevice> GetAllDevices()
        {
            return provider.selectAll();
        }
        public int AddDevice(SmartDevice device)
        {
            return provider.insert(device);
        }
        public int DeleteDevice(SmartDevice device)
        {
            return provider.delete(device);
        }
        public int UpdateDevice(SmartDevice device)
        {
            return provider.update(device);
        }
        public SmartDevice GetDeviceByID(string deviceID)
        {
            return provider.SelectSmartdevice(deviceID);
        }

    }
}

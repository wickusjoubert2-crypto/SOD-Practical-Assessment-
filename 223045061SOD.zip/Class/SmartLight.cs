﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FR1.BL.Class
{
   public  class SmartLight:SmartDevice
    {
        public int Brightness { get; set; } // end property 
        public override string Display()
        {
            return base.Disply() + $" Brightness: {Brightness}";
        }
    }
}

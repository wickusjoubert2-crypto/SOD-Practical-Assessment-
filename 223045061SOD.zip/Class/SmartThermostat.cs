﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FR1.BL.Class
{
   public  class SmartThermostat: SmartDevice
    {
        public double Temperature { get; set; } // end property
        public override string Display()
        {
            return base.Disply() + $" Temperature: {Temperature}";
        }
    }
}
